#!/bin/bash

OPTIONS="--options="${TOOLCONFIG}"/style.cfg -n"

echo $OPTIONS
